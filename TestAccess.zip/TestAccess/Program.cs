﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestAccess.CFHmarkets;

namespace TestAccess
{
    using TestAccess.CFHBrokerDataAccess;

    class Program
    {
        static void Main(string[] args)
        {
            using (var boServiceClient = new BrokerDataServiceClient())
            {
                if (boServiceClient.ClientCredentials != null)
                {
                    boServiceClient.ClientCredentials.UserName.UserName = args[0];
                    boServiceClient.ClientCredentials.UserName.Password = args[1];
                }

                boServiceClient.Open();
                var ret = boServiceClient.ValidateService();  // Fails here with An error (The request was aborted: The request was canceled.) occurred while transmitting data over the HTTP channel.
                var clientId = 0;  // How do you get this?
                var clientInfo = boServiceClient.GetClientInfo(clientId);
                boServiceClient.Close();
            }

            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestAccess
{
    using TestAccess.CFHBrokerDataAccess;

    public class BrokerWSClient
{
BrokerDataServiceClient _BOServiceClient;
int _clientId;
int _accountId;
DateTime _fromTime;
DateTime _toTime;
int _pageSize;
int _pageNumber;
public BrokerWSClient(string userName, string password, int clientId, int accountId,
DateTime fromTime, DateTime toTime, int pageSize, int pageNumber)
{
_BOServiceClient = new BrokerDataServiceClient();
_BOServiceClient.ClientCredentials.UserName.UserName = userName;
_BOServiceClient.ClientCredentials.UserName.Password = password;
_clientId = clientId;
_accountId = accountId;
_fromTime = fromTime;
_toTime = toTime;
_pageSize = pageSize;
_pageNumber = pageNumber;
}
/*
* This is simply a test method to validate transport layer security.
*/
public bool ValidateService()
{
bool _valid = _BOServiceClient.ValidateService();
return _valid;
}
/*
* Get the client detail information given a clientId.
*/
public void GetBOClientInfo()
{
ClientInfo clientInfo = _BOServiceClient.GetClientInfo(_clientId);
Console.Out.WriteLine("Client - Id: " + clientInfo.Id);
Console.Out.WriteLine("Client - Name: " + clientInfo.Name);
Console.Out.WriteLine("Client - Active: " + clientInfo.IsActive);
Console.Out.WriteLine("Client - Broker Id: " + clientInfo.BrokerId);
Console.Out.WriteLine("Client - Broker Name: " + clientInfo.BrokerName);
Console.Out.WriteLine("Client - Currency: " + clientInfo.CurrencyCode);
Console.Out.WriteLine("Client - Margin Requirement Profile: " +
clientInfo.MarginRequirementProfile);
Console.Out.WriteLine("Client - Margin Action Profile: " +
clientInfo.MarginActionProfile);
Console.Out.WriteLine("Client - Tracks Enabled: " + clientInfo.TracksEnabled);
Console.Out.WriteLine("Client - Credit Limit: " + clientInfo.CreditLimit);
Console.Out.WriteLine("Client - Email: " + clientInfo.Email);
}
/*
* Get a list of Accounts associated with a given client (clientId).
*/
public void GetBOAccountList()
{
IEnumerable<AccountDescription> accountList =
_BOServiceClient.GetAccounts(_clientId);
int i = 1;
foreach (AccountDescription acct in accountList)
{
Console.Out.WriteLine("****#" + i);
Console.Out.WriteLine("Acocunt - Id: " + acct.AccountId);
Console.Out.WriteLine("Acocunt - Name: " + acct.AccountName);
Console.Out.WriteLine("Acocunt - Type: " + acct.AccountType);
i++;
}
}
/*
* Get a list of Cash activity records associated with a given account (accountId).
*/
public void GetBOCashActivities()
{
CashActivities cashes = _BOServiceClient.GetCashActivities(_accountId, _fromTime,
_toTime, _pageSize, _pageNumber);
Console.Out.WriteLine("****Total pages of cash activities: " +
cashes.TotalPages);
int i = 1;
foreach (CashActivityInfo cash in cashes.CashActivitiesList)
{
Console.Out.WriteLine("****#" + i);
Console.Out.WriteLine("Cash Activity - Id: " + cash.CashActivityId);
Console.Out.WriteLine("Cash Activity - Type: " + cash.CashActivityType);
Console.Out.WriteLine("Cash Activity - Correlation Id: " +
cash.CorrelationId);
Console.Out.WriteLine("Cash Activity - Counter Account: " +
cash.ContraAcountId);
Console.Out.WriteLine("Cash Activity - Amount: " + cash.Amount);
Console.Out.WriteLine("Cash Activity - Currency: " + cash.Currency);
Console.Out.WriteLine("Cash Activity - Trade Date: " + cash.TradeDate);
Console.Out.WriteLine("Cash Activity - Value Date: " + cash.ValueDate);
Console.Out.WriteLine("Cash Activity - Activity Time: " + cash.ActivityTime);
Console.Out.WriteLine("Cash Activity - Comment: " + cash.Comment);
i++;
}
}
}
}